package tasty.go.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tasty.go.app.dto.AiReqDTO;
import tasty.go.app.service.AiService;

import java.util.List;

@RestController
@RequestMapping("/api/ai")
public class AiController {
    @Autowired private AiService aiService;
    @PostMapping("/chat")
    public String generate(@RequestBody List<AiReqDTO.Content> prompt) {
        return aiService.chat(prompt);
    }
}
