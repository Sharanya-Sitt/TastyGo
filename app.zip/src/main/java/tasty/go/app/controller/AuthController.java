package tasty.go.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tasty.go.app.dto.LoginDTO;
import tasty.go.app.dto.UserType;
import tasty.go.app.service.AuthService;
import tasty.go.app.service.OtpService;

@RestController
@RequestMapping("/auth")
@CrossOrigin("http://localhost:5173")
public class AuthController {
    @Autowired
    private AuthService authService;
    @Autowired private OtpService otpService;

    @PostMapping("/send-otp/{userType}")
    public ResponseEntity<String> sendOtp(@RequestBody String email,@PathVariable UserType userType) {
        return ResponseEntity.ok(otpService.sendOtp(userType,email));
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody LoginDTO loginData){
        String loginStatus = authService.loginUser(loginData.getEmail(), loginData.getPassword());
        if(loginStatus.equals("Invalid Credentials") || loginStatus.isEmpty()){
            return ResponseEntity.status(401).body(loginStatus);
        }
        return ResponseEntity.status(200).body(loginStatus);
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(
            @RequestParam("userType") UserType userType,
            @RequestPart("data") Object userData,
            @RequestPart("image") MultipartFile profileImage
    ) {
        try {
            String response = authService.registerUser(userData,userType, profileImage);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Registration failed: " + e.getMessage());
        }
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(
            @RequestParam String email,
            @RequestParam UserType userType,
            @RequestBody int otp
    ) {
        String result = authService.forgetPassword(email, userType,otp);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/change-password")
    public ResponseEntity<String> changePassword(
            @RequestHeader("Authorization") String token,
            @RequestHeader("oldPassword") String oldPassword,
            @RequestHeader("newPassword") String newPassword,
            @RequestParam UserType userType,
            @RequestBody int otp
    ) {
        String result = authService.changePassword(token, oldPassword, newPassword, userType,otp);
        return ResponseEntity.ok(result);
    }
}
