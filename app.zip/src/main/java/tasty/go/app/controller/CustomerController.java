package tasty.go.app.controller;

import com.razorpay.RazorpayException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tasty.go.app.dto.RestaurantsDTO;
import tasty.go.app.model.Order;
import tasty.go.app.service.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
@CrossOrigin("http://localhost:5173")
public class CustomerController {
    @Autowired private CustomerService customerService;
    @Autowired private RestaurantService restaurantService;
    @Autowired private CartService cartService;
    @Autowired private PaymentService paymentService;
    @Autowired private DeliveryManService deliveryManService;
    @Autowired private MenuService menuService;
    @Autowired OtpService otpService;
    @Autowired private OrderService orderService;

    @GetMapping("/home")
    public ResponseEntity<List<RestaurantsDTO>> getRestaurantsForHomePage(@RequestHeader("Authorization") String token){
        return ResponseEntity.ok(restaurantService.getNearbyRestaurants(token));
    }

    //API calls related to cart management

    @PostMapping("/cart/add/{restaurantId}/{menuId}/{quantity}/{price}")
    public ResponseEntity<String> addToCart(
            @RequestHeader("Authorization") String token,
            @PathVariable Long restaurantId,
            @PathVariable Long menuId,
            @PathVariable int quantity,
            @PathVariable double price
    ) {
        String response = cartService.addToCart(token, restaurantId, menuId, quantity, price);
        if (response.equals("Item added to cart")) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.badRequest().body(response);
    }
    @GetMapping("/cart/items")
    public ResponseEntity<Object[]> getCartItems(@RequestHeader("Authorization") String token) {
        Object[] cartData = cartService.fetchCartItems(token);
        return ResponseEntity.ok(cartData);
    }

    @DeleteMapping("/cart/items/delete/{menuId}")
    public ResponseEntity<String> deleteCartItem(
            @RequestHeader("Authorization") String token,
            @PathVariable Long menuId
    ) {
        String result = cartService.deleteFromCart(token, menuId);
        return result.equals("Item removed") ?
                ResponseEntity.ok(result) :
                ResponseEntity.badRequest().body(result);
    }

    @DeleteMapping("/cart/clean")
    public ResponseEntity<String> clearCart(@RequestHeader("Authorization") String token) {
        String result = cartService.clearCart(token);
        return result.contains("successfully") ?
                ResponseEntity.ok(result) :
                ResponseEntity.badRequest().body(result);
    }
    //Cart management ends
    @GetMapping("/my-orders")
    public ResponseEntity<List<Order>> getOrders(@RequestHeader("Authorization") String token) {
        return ResponseEntity.ok(customerService.getOrders(token));
    }

    @PostMapping("/order/payment")
    public ResponseEntity<String> paymentReq(@RequestHeader("Authorization") String token) throws RazorpayException {
        return ResponseEntity.ok(paymentService.createOrder(token));
    }
    @PostMapping("/order/checkout/{paymentMode}")
    public ResponseEntity<String> checkOut(@RequestHeader("Authorization") String token,
                                           @PathVariable String paymentMode,
                                           @RequestBody String paymentId) throws RazorpayException {
        return ResponseEntity.ok(orderService.checkout(token, paymentMode, paymentId));
    }
    @PostMapping("/order/rate/{restaurantId}/{rating}")
    public ResponseEntity<String> rateRestaurant(@PathVariable Long restaurantId, @PathVariable int rating) {
        return ResponseEntity.ok(restaurantService.rateRestaurant(restaurantId, rating));
    }
    @PostMapping("/order/deliveryman/{orderId}/{rating}")
    public ResponseEntity<String> rateDeliveryMan(@RequestHeader("Authorization") String token,
                                                  @PathVariable Long orderId,
                                                  @PathVariable int rating) {
        return ResponseEntity.ok(deliveryManService.rateDeliveryMan(token, orderId, rating));
    }

}
