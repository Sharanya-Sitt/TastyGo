package tasty.go.app.controller;

import org.apache.catalina.LifecycleState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tasty.go.app.model.Order;
import tasty.go.app.service.DeliveryManService;
import tasty.go.app.util.JwtUtil;

import java.util.List;

@RestController
@RequestMapping("/api/deliveryman")
public class DeliveryManController {
    @Autowired private DeliveryManService deliveryManService;
    @Autowired private JwtUtil jwtUtil;

    @PostMapping("/accept/{orderId}")
    public ResponseEntity<String> acceptDeliveryOffer(@RequestHeader("Authorization") String token,
                                                      @PathVariable Long orderId) {
        return ResponseEntity.ok(deliveryManService.acceptDeliveryRequest(token, orderId));
    }
    @PostMapping("/availability/{availability}")
    public ResponseEntity<String> updateAvailability(@RequestHeader("Authorization") String token,
                                                     @PathVariable boolean availability) {
        deliveryManService.updateAvailability(token, availability);
        return ResponseEntity.ok("Availability updated");
    }
    @GetMapping("/orders")
    public ResponseEntity<List<Order>> getDeliveredOrders(@RequestHeader("Authorization") String token) {
        return ResponseEntity.ok(deliveryManService.getOrdersDeliveredByDeliveryMan(token));
    }
    @GetMapping("/current-order")
    public ResponseEntity<Order> getCurrentOrder(@RequestHeader("Authorization") String token) {
        return ResponseEntity.ok(deliveryManService.getCurrentOrder(token));
    }
}
