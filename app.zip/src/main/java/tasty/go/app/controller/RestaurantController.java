package tasty.go.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tasty.go.app.dto.RestaurantsDTO;
import tasty.go.app.model.Menu;
import tasty.go.app.model.Order;
import tasty.go.app.model.Restaurant;
import tasty.go.app.service.*;

import java.util.List;

@RestController
@RequestMapping("/api/restaurant")
@CrossOrigin("http://localhost:5173")
public class RestaurantController {
    @Autowired private CustomerService customerService;
    @Autowired private RestaurantService restaurantService;
    @Autowired private CartService cartService;
    @Autowired private PaymentService paymentService;
    @Autowired private DeliveryManService deliveryManService;
    @Autowired private MenuService menuService;
    @Autowired private OtpService otpService;
    @Autowired private OrderService orderService;

    @GetMapping("/home")
    public ResponseEntity<List<RestaurantsDTO>> getRestaurantsForHomePage(String token){
        return ResponseEntity.ok(restaurantService.getNearbyRestaurants(token));
    }
    @GetMapping("/orders")
    public ResponseEntity<List<Order>> getOrders(@RequestHeader("Authorization") String token) {
        return ResponseEntity.ok(restaurantService.getOrders(token));
    }
    @PutMapping("/{orderId}/{status}")
    public ResponseEntity<String> updateOrderStatus(
            @PathVariable Long orderId,
            @PathVariable String status,
            @RequestHeader("Authorization") String token) {
        String result = restaurantService.updateOrderStatus(orderId, status, token);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/{orderId}/assign-delivery")
    public ResponseEntity<String> assignDeliveryBoy(
            @PathVariable Long orderId,
            @RequestHeader("Authorization") String token) {
        restaurantService.assignDeliveryBoy(token, orderId);
        return ResponseEntity.ok("Delivery request sent to available delivery personnel.");
    }

    @GetMapping("/menu")
    public ResponseEntity<List<Menu>> getMenuItems(@RequestParam Long restaurantId) {
        return ResponseEntity.ok(menuService.getMenuItemsByRestaurantId(restaurantId));
    }

    @PostMapping("/menu")
    public ResponseEntity<Menu> addMenuItem(
            @ModelAttribute Menu menu,
            @RequestHeader("Authorization") String token,
            @RequestParam("image") MultipartFile image) throws Exception {
        Menu savedMenu = menuService.addMenuItem(menu, token, image);
        return ResponseEntity.ok(savedMenu);
    }

    @PutMapping("/menu/{menuId}/availability")
    public ResponseEntity<Menu> updateAvailability(
            @PathVariable Long menuId,
            @RequestHeader("Authorization") String token,
            @RequestParam String availability) throws Exception {
        Menu updated = menuService.updateAvailability(menuId, token, availability);
        return ResponseEntity.ok(updated);
    }

    @PutMapping("/menu/{menuId}/price")
    public ResponseEntity<Menu> updatePrice(
            @PathVariable Long menuId,
            @RequestHeader("Authorization") String token,
            @RequestParam Double price) throws Exception {
        Menu updated = menuService.updatePrice(menuId, token, price);
        return ResponseEntity.ok(updated);
    }

    @PutMapping("/menu/{menuId}/discount")
    public ResponseEntity<Menu> updateDiscount(
            @PathVariable Long menuId,
            @RequestHeader("Authorization") String token,
            @RequestParam int discount) throws Exception {
        Menu updated = menuService.updateDiscount(menuId, token, discount);
        return ResponseEntity.ok(updated);
    }

    @PutMapping("/menu/{menuId}/description")
    public ResponseEntity<Menu> updateDescription(
            @PathVariable Long menuId,
            @RequestHeader("Authorization") String token,
            @RequestParam String description) throws Exception {
        Menu updated = menuService.updateDescription(menuId, token, description);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/menu/{menuId}")
    public ResponseEntity<Menu> deleteMenuItem(
            @PathVariable Long menuId,
            @RequestHeader("Authorization") String token) throws Exception {
        Menu deleted = menuService.deleteMenuItem(menuId, token);
        return ResponseEntity.ok(deleted);
    }
    @GetMapping("/search")
    public ResponseEntity<List<Restaurant>> search(@RequestParam String q){
        return ResponseEntity.ok(restaurantService.search(q));
    }
}
