package tasty.go.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tasty.go.app.model.Menu;

import java.util.List;

@Repository
public interface MenuRepository extends JpaRepository<Menu, Long> {
    @Query("select m from Menu m where m.restaurant_id = :restaurantId")
    List<Menu> findByRestaurantId(@Param("restaurantId") Long restaurantId);
}
