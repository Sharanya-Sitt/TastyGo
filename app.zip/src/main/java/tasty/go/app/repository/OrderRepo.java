package tasty.go.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tasty.go.app.model.Order;

import java.util.List;

@Repository
public interface OrderRepo extends JpaRepository<Order,Long> {
    @Query("Select o from Order o where restaurantId = :restaurantId")
    List<Order> findByRestaurantId(@Param("restaurantId") Long restaurantId);

    @Query("Select o from Order o where customerId = :customerId")
    List<Order> findByCustomerId(@Param("customerId") Long customerId);

    List<Order> findByDeliveryManId(Long id);
}
