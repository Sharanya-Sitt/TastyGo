package tasty.go.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tasty.go.app.model.Restaurant;

import java.util.List;

@Repository
public interface RestaurantRepo extends JpaRepository<Restaurant, Long>{
    public Restaurant findByName(String name);
    public Restaurant findByEmail(String email);

    @Query(value = """
    SELECT DISTINCT r.*
    FROM restaurant r
    LEFT JOIN menu m ON r.id = m.restaurant_id
    WHERE LOWER(r.name) LIKE LOWER(CONCAT('%', :keyword, '%'))
       OR LOWER(m.food_name) LIKE LOWER(CONCAT('%', :keyword, '%'))
       OR LOWER(m.category) LIKE LOWER(CONCAT('%', :keyword, '%'))
       OR LOWER(m.type) LIKE LOWER(CONCAT('%', :keyword, '%'))
    """, nativeQuery = true)
    public List<Restaurant> searchRestaurantsByKeyword(@Param("keyword") String keyword);

}
