package tasty.go.app.repository;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tasty.go.app.model.Cart;

import java.util.List;

@Repository
public interface CartRepo extends JpaRepository<Cart, Long> {

    @Modifying
    @Transactional
    @Query("DELETE FROM Cart c WHERE c.userId = :userId")
    int deleteByUserId(@Param("userId") Long userId);

    @Modifying
    @Transactional
    @Query("Delete from Cart c where c.userId = :userId and c.menuId = :menuId")
    int removeItemFromCart(@Param("userId") Long userId, @Param("menuId") Long menuId);

    @Query("SELECT SUM(c.price * c.quantity) FROM Cart c WHERE c.userId = :userId")
    Double getTotalCartPriceByUserId(@Param("userId") Long userId);

    List<Cart> findByUserId(Long id);
}
