package tasty.go.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tasty.go.app.model.DeliveryMan;

import java.util.List;

@Repository
public interface DeliveryManRepo extends JpaRepository<DeliveryMan,Long> {
    DeliveryMan findByEmail(String email);

    List<DeliveryMan> findByCity(String city);
}
