package tasty.go.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tasty.go.app.model.Customer;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Long> {
    public  Customer findByEmail(String email);
}
