package tasty.go.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tasty.go.app.dto.RestaurantsDTO;
import tasty.go.app.model.*;
import tasty.go.app.repository.DeliveryManRepo;
import tasty.go.app.repository.MenuRepository;
import tasty.go.app.repository.OrderRepo;
import tasty.go.app.repository.RestaurantRepo;
import tasty.go.app.util.DistanceCalculator;
import tasty.go.app.util.EmailUtil;
import tasty.go.app.util.JwtUtil;

import java.util.ArrayList;
import java.util.List;

@Service
public class RestaurantService {
    @Autowired
    private RestaurantRepo restaurantRepo;
    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private EmailUtil emailUtil;
    @Autowired
    private OrderRepo orderRepo;
    @Autowired
    private DistanceCalculator distanceCalculator;
    @Autowired
    private DeliveryManRepo deliveryManRepo;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private MenuRepository menuRepository;


    public List<Order> getOrders(String token) {
        Restaurant restaurant = getLoggedInRestaurant(token.substring(7));
        return orderRepo.findByRestaurantId(restaurant.getId());
    }

    public String updateOrderStatus(Long orderId, String status, String token) {
        String email = jwtUtil.getEmailFromToken(token.substring(7));
        Order order = orderRepo.findById(orderId).orElse(null);
        if (order == null) return "Order not found.";
        DeliveryMan deliveryMan = deliveryManRepo.findByEmail(email);
        if (deliveryMan != null) {
            if (order.getDeliveryManId() != null && order.getDeliveryManId().equals(deliveryMan.getId())) {
                order.setStatus(status);
                orderRepo.save(order);
                return "Order status updated by Delivery Man.";
            } else return "Unauthorized to update the order status.";
        }
        Restaurant restaurant = restaurantRepo.findByEmail(email);
        if (restaurant != null) {
            if (order.getRestaurantId().equals(restaurant.getId())) {
                order.setStatus(status);
                orderRepo.save(order);
                return "Order status updated by Restaurant.";
            } else {
                return "This order does not belong to your restaurant.";
            }
        }
        return "Unauthorized to update the order status.";
    }

    public void assignDeliveryBoy(String token, Long orderId) {
        Order order = orderRepo.findById(orderId).orElse(null);
        if (order == null) return;

        Restaurant restaurant = getLoggedInRestaurant(token);
        List<DeliveryMan> deliveryMen = deliveryManRepo.findByCity(restaurant.getCity());

        for (DeliveryMan dm : deliveryMen) {
            double distance = DistanceCalculator.calculateDistance(
                    restaurant.getLatitude(), restaurant.getLongitude(),
                    dm.getLatitude(), dm.getLongitude()
            );
            String subject = "🚚 New Delivery Request from TastyGo";

            String body = """
                        <html>
                        <body style='font-family: Arial, sans-serif; color: #333; line-height: 1.6;'>
                            <h2 style='color: #4CAF50;'>New Delivery Assignment</h2>
                            <p>Hi %s,</p>
                    
                            <p>You have a new delivery opportunity from <strong>%s</strong>.</p>
                            <ul>
                                <li><strong>Order ID:</strong> #%d</li>
                                <li><strong>Restaurant Distance from you:</strong> %.2f km</li>
                                <li><strong>Order address:</strong> %s</li>
                            </ul>
                    
                            <p>If you're available to deliver this order, please click the button below to accept it:</p>
                    
                            <a href='http://localhost:8080/api/deliveryman/accept/%d' 
                               style='display: inline-block; padding: 10px 20px; font-size: 16px; 
                                      color: white; background-color: #28a745; text-decoration: none; 
                                      border-radius: 5px; margin-top: 10px;'>
                                ✅ Accept Delivery
                            </a><br><br>
                            <a href='http://localhost:8080/api/deliveryman/accept/%d'>If the button doesn't work, click here</a>
                            </a>
                    
                            <p>Thank you for being a part of TastyGo!</p>
                            <p style='font-size: 0.9em; color: #888;'>This is an automated message. Please do not reply.</p>
                        </body>
                        </html>
                    """.formatted(
                    dm.getName(),restaurant.getName(),order.getId(),distance,order.getDeliveryAddress(),order.getId(),order.getId()
            );
            if (dm.getRating() > 2.5 && dm.isAvailable()) {
                emailUtil.sendHtmlEmail(dm.getEmail(), subject, body);
            }
        }
    }

    public String rateRestaurant(Long restaurantId, double newRating) {
        if (newRating < 1 || newRating > 5) {
            return "Rating must be between 1 and 5.";
        }

        Restaurant restaurant = restaurantRepo.findById(restaurantId).orElse(null);
        if (restaurant == null) {
            return "Restaurant not found.";
        }

        int currentCount = restaurant.getNumberOfRatings();
        double currentTotal = restaurant.getRating() * currentCount;

        double newAverage = (currentTotal + newRating) / (currentCount + 1);

        restaurant.setRating(newAverage);
        restaurant.setNumberOfRatings(currentCount + 1);
        restaurantRepo.save(restaurant);

        return String.format("Thank you! New average rating for %s is %.2f", restaurant.getName(), newAverage);
    }

    public List<RestaurantsDTO> getNearbyRestaurants(String token) {
        Customer customer = customerService.getLoggedInUser(token.substring(7));
        double userLat = customer.getLatitude();
        double userLng = customer.getLongitude();

        List<Restaurant> allRestaurants = restaurantRepo.findAll(); // Ideally, filter by city or bounding box
        List<RestaurantsDTO> result = new ArrayList<>();

        for (Restaurant restaurant : allRestaurants) {
            double distance = DistanceCalculator.calculateDistance(userLat, userLng, restaurant.getLatitude(), restaurant.getLongitude());
            if (distance <= 15.0) {
                List<Menu> menuItems = menuRepository.findByRestaurantId(restaurant.getId());

                double avgDiscount = menuItems.stream()
                        .mapToInt(Menu::getDiscount)
                        .average()
                        .orElse(0.0);

                result.add(new RestaurantsDTO(
                        restaurant.getId(),
                        restaurant.getName(),
                        restaurant.getRestaurantLogo(),
                        restaurant.getRating(),
                        restaurant.getNumberOfRatings(),
                        avgDiscount,
                        distance
                ));
            }
        }

        // Sort by highest rating first
        result.sort((a, b) -> Double.compare(b.getRating(), a.getRating()));
        return result;
    }

    public List<Restaurant> search(String keyword) {
        return restaurantRepo.searchRestaurantsByKeyword(keyword);
    }


    public Restaurant getLoggedInRestaurant(String token) {
        String restaurantEmail = jwtUtil.getEmailFromToken(token.substring(7));
        return restaurantRepo.findByEmail(restaurantEmail);
    }
}
