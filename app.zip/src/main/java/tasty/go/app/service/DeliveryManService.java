package tasty.go.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tasty.go.app.controller.DeliveryManController;
import tasty.go.app.model.Customer;
import tasty.go.app.model.DeliveryMan;
import tasty.go.app.model.Order;
import tasty.go.app.repository.DeliveryManRepo;
import tasty.go.app.repository.OrderRepo;
import tasty.go.app.util.JwtUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DeliveryManService {
    @Autowired
    private DeliveryManRepo deliveryManRepo;
    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private OrderRepo orderRepo;
    @Autowired private CustomerService customerService;

    public String acceptDeliveryRequest(String token, Long orderId) {
        DeliveryMan deliveryMan = getLoggedInDeliveryMan(token.substring(7));
        if(deliveryMan == null) return "You must be logged in to the system to accept delivery request";
        Order order = orderRepo.findById(orderId).orElse(null);
        if (order == null || order.getStatus().equals("DELIVERY ASSIGNED")|| order.getDeliveryManId() != null) {
            return "Delivery already assigned for this order";}
        else if (order.getStatus().equals("PLACED")) {
            order.setStatus("DELIVERY ASSIGNED");
            order.setDeliveryManId(deliveryMan.getId());
            orderRepo.save(order);
            return "Delivery assigned successfully";
        }
        return "Delivery already assigned for this order or order not found";
    }

    public void updateAvailability(String token, boolean availability) {
        DeliveryMan deliveryMan = getLoggedInDeliveryMan(token.substring(7));
        deliveryMan.setAvailable(availability);
        deliveryManRepo.save(deliveryMan);
    }

    public String rateDeliveryMan(String token, Long orderId, int rating){
        Customer customer = customerService.getLoggedInUser(token.substring(7));
        if(customer == null) return "You must be logged in to the system to rate delivery man";
        Order order = orderRepo.findById(orderId).orElse(null);
        assert order != null;
        DeliveryMan deliveryMan = deliveryManRepo.findById(order.getDeliveryManId()).orElse(null);
        assert deliveryMan != null;
        deliveryMan.setRating((deliveryMan.getRating() * deliveryMan.getRatingCount() + rating) / (deliveryMan.getRatingCount() + 1));
        deliveryMan.setRatingCount(deliveryMan.getRatingCount() + 1);
        deliveryManRepo.save(deliveryMan);
        return "Delivery man rated successfully";
    }

    public List<Order> getOrdersDeliveredByDeliveryMan(String token) {
        DeliveryMan deliveryMan = getLoggedInDeliveryMan(token.substring(7));
        return orderRepo.findByDeliveryManId(deliveryMan.getId())
                .stream()
                .filter(order -> "DELIVERED".equalsIgnoreCase(order.getStatus()))
                .collect(Collectors.toList());
    }

    public Order getCurrentOrder(String token) {
        DeliveryMan deliveryMan = getLoggedInDeliveryMan(token.substring(7));
        return orderRepo.findByDeliveryManId(deliveryMan.getId())
                .stream()
                .filter(order -> !"DELIVERED".equals(order.getStatus()))
                .findFirst()
                .orElse(null);
    }


    public DeliveryMan getLoggedInDeliveryMan(String token) {
        String username = jwtUtil.getEmailFromToken(token);
        return deliveryManRepo.findByEmail(username);
    }

}

