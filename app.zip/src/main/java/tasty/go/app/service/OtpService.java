package tasty.go.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tasty.go.app.dto.UserType;
import tasty.go.app.model.Customer;
import tasty.go.app.model.DeliveryMan;
import tasty.go.app.model.Restaurant;
import tasty.go.app.repository.CustomerRepo;
import tasty.go.app.repository.DeliveryManRepo;
import tasty.go.app.repository.RestaurantRepo;
import tasty.go.app.util.EmailUtil;
import tasty.go.app.util.JwtUtil;

import java.time.LocalDateTime;

@Service
public class OtpService {
    @Autowired private CustomerRepo customerRepo;
    @Autowired private RestaurantRepo restaurantRepo;
    @Autowired private DeliveryManRepo deliveryManRepo;
    @Autowired private EmailUtil emailUtil;
    @Autowired private JwtUtil jwtUtil;

    public String sendOtp(UserType role, String email) {
        switch (role) {
            case CUSTOMER -> {
                Customer customer = customerRepo.findByEmail(email);
                if (customer == null) return "Customer not found.";
                int otp = (int) (Math.random() * 9000) + 1000;
                customer.setOtp(otp);
                customer.setOtp_expiry(LocalDateTime.now().plusMinutes(5));
                customerRepo.save(customer);
                String subject = "OTP from TastyGo";
                String body = "<h1>Hi " + customer.getName() + "</h1><br><br><p>One time password is " + otp + ".</p>" +
                        "<br><p>Use it withing 5 minutes.</p>" +
                        "<br><br><p>Best regards,<br>TastyGo Team</p>";
                emailUtil.sendHtmlEmail(customer.getEmail(), subject, body);
            }
            case RESTAURANT -> {
                Restaurant restaurant = restaurantRepo.findByEmail(email);
                if(restaurant == null) return "Restaurant not found.";
                int otp = (int) (Math.random() * 9000) + 1000;
                restaurant.setOtp(otp);
                restaurant.setOtp_expiry(LocalDateTime.now().plusMinutes(5));
                restaurantRepo.save(restaurant);
                String subject = "OTP from TastyGo";
                String body = "<h1>Hi " + restaurant.getName() + "</h1><br><br><p>One time password is " + otp + ".</p>" +
                        "<br><p>Use it withing 5 minutes.</p>" +
                        "<br><br><p>Best regards,<br>TastyGo Team</p>";
                emailUtil.sendHtmlEmail(restaurant.getEmail(), subject, body);
            }
            case DELIVERY_MAN -> {
                DeliveryMan deliveryMan = deliveryManRepo.findByEmail(email);
                if(deliveryMan == null) return "Delivery man not found.";
                int otp = (int) (Math.random() * 9000) + 1000;
                deliveryMan.setOtp(otp);
                deliveryMan.setOtp_expiry(LocalDateTime.now().plusMinutes(5));
                deliveryManRepo.save(deliveryMan);
                String subject = "OTP from TastyGo";
                String body = "<h1>Hi " + deliveryMan.getName() + "</h1><br><br><p>One time password is " + otp + ".</p>" +
                        "<br><p>Use it withing 5 minutes.</p>" +
                        "<br><br><p>Best regards,<br>TastyGo Team</p>";
                emailUtil.sendHtmlEmail(deliveryMan.getEmail(), subject, body);
            }
        } return "OTP sent successfully.";
    }

    public boolean verifyOtp(String email, UserType role, int otp) {
        switch (role) {
            case CUSTOMER -> {
                Customer customer = customerRepo.findByEmail(email);
                return customer.getOtp() != otp || !customer.getOtp_expiry().isAfter(LocalDateTime.now());
            }
            case RESTAURANT -> {
                Restaurant restaurant = restaurantRepo.findByEmail(email);
                return restaurant.getOtp() != otp || !restaurant.getOtp_expiry().isAfter(LocalDateTime.now());
            }
            case DELIVERY_MAN -> {
                DeliveryMan deliveryMan = deliveryManRepo.findByEmail(email);
                return deliveryMan.getOtp() != otp || !deliveryMan.getOtp_expiry().isAfter(LocalDateTime.now());
            }
        }
        return true;
    }


}
