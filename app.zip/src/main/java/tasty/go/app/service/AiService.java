package tasty.go.app.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import tasty.go.app.dto.AiReqDTO;
import tasty.go.app.dto.AiResDTO;

import java.util.List;

@Service
public class AiService {

    @Value("${gemini.api.key}")
    private String apiKey;

    @Value("${gemini.api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public String chat(List<AiReqDTO.Content> history) {
        AiReqDTO request = new AiReqDTO();
        request.setContents(history);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        String fullUrl = UriComponentsBuilder.fromHttpUrl(apiUrl)
                .queryParam("key", apiKey)
                .toUriString();

        HttpEntity<AiReqDTO> entity = new HttpEntity<>(request, headers);
        ResponseEntity<AiResDTO> response = restTemplate.postForEntity(fullUrl, entity, AiResDTO.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            assert response.getBody() != null;
            return response.getBody()
                    .getCandidates()
                    .getFirst()
                    .getContent()
                    .getParts()
                    .getFirst()
                    .getText();
        } else {
            return "Error from Gemini API: " + response.getStatusCode();
        }
    }
    public void updateHistory(List<AiReqDTO.Content> history, String question, String answer) {
        AiReqDTO.Content userContent = new AiReqDTO.Content();
        userContent.setRole("user");
        userContent.setParts(List.of(new AiReqDTO.Part(question)));
        history.add(userContent);
        AiReqDTO.Content modelContent = new AiReqDTO.Content();
        modelContent.setRole("model"); // <-- IMPORTANT
        modelContent.setParts(List.of(new AiReqDTO.Part(answer)));
        history.add(modelContent);
    }
}
