package tasty.go.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import tasty.go.app.model.Customer;
import tasty.go.app.model.Order;
import tasty.go.app.repository.CustomerRepo;
import tasty.go.app.repository.OrderRepo;
import tasty.go.app.util.EmailUtil;
import tasty.go.app.util.FileStorageUtil;
import tasty.go.app.util.JwtUtil;

import java.util.List;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepo customerRepo;
    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private EmailUtil emailUtil;
    @Autowired
    private FileStorageUtil fileStorageUtil;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private OrderRepo orderRepo;

    public List<Order> getOrders(String token) {
        Customer customer = getLoggedInUser(token.substring(7));
        return orderRepo.findByCustomerId(customer.getId());
    }
    public Customer getLoggedInUser(String token) {
        String email = jwtUtil.getEmailFromToken(token);
        return customerRepo.findByEmail(email);
    }
}
