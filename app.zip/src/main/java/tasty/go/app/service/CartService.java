package tasty.go.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tasty.go.app.model.Cart;
import tasty.go.app.model.Customer;
import tasty.go.app.model.Menu;
import tasty.go.app.repository.CartRepo;
import tasty.go.app.repository.MenuRepository;
import tasty.go.app.repository.RestaurantRepo;

import java.util.List;

@Service
public class CartService {
    @Autowired
    private CartRepo cartRepo;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private RestaurantRepo restaurantRepo;
    @Autowired
    private MenuRepository menuRepository;

    public String addToCart(String token, Long restaurantId, Long menuId,int quantity, double price){
        Customer customer = customerService.getLoggedInUser(token);
        Cart cart = new Cart();
        cart.setMenuId(menuId);
        cart.setRestaurantId(restaurantId);
        cart.setUserId(customer.getId());
        cart.setQuantity(quantity);
        cart.setPrice(price);
        try { cartRepo.save(cart);
            return "Item added to cart";}
        catch (Exception e){return e.toString();}
    }

    public Object[] fetchCartItems(String token){
        Customer customer = customerService.getLoggedInUser(token);
        List<Cart> cartItems = cartRepo.findByUserId(customer.getId());
        Double totalPrice = cartRepo.getTotalCartPriceByUserId(customer.getId());
        return new Object[]{cartItems, totalPrice != 0? totalPrice: 0.0};
    }


    public String deleteFromCart(String token, Long menuId){
        Customer customer = customerService.getLoggedInUser(token);
        int n = cartRepo.removeItemFromCart(customer.getId(),menuId);
        if(n>0){return "Item removed";}
        return "Failed to remove item";
    }

    public String clearCart(String token){
        Customer customer = customerService.getLoggedInUser(token);
        int n = cartRepo.deleteByUserId(customer.getId());
        if(n>0){return "Cart cleared successfully";}
        return "Failed to clear cart for user" + customer.getName();
    }
}
