package tasty.go.app.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import tasty.go.app.dto.UserType;
import tasty.go.app.model.Customer;
import tasty.go.app.model.DeliveryMan;
import tasty.go.app.model.Restaurant;
import tasty.go.app.repository.CustomerRepo;
import tasty.go.app.repository.DeliveryManRepo;
import tasty.go.app.repository.RestaurantRepo;
import tasty.go.app.util.EmailUtil;
import tasty.go.app.util.FileStorageUtil;
import tasty.go.app.util.JwtUtil;

import java.util.UUID;

@Service
public class AuthService {
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private CustomerRepo customerRepo;
    @Autowired
    private RestaurantRepo restaurantRepo;
    @Autowired
    private DeliveryManRepo deliveryManRepo;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private EmailUtil emailUtil;
    @Autowired
    private FileStorageUtil fileStorageUtil;
    @Autowired private OtpService otpService;

    public String loginUser(String email, String password) {
        Authentication authentication;
        try {
            authentication = authenticate(email, password);
        } catch (Exception e) {
            return "Invalid Credentials";
        }
        String authenticatedEmail = ((org.springframework.security.core.userdetails.User) authentication.getPrincipal()).getUsername();

        return jwtUtil.generateToken(authenticatedEmail);
    }
    private Authentication authenticate(String username, String password) {
        return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
    }

    public String registerUser(Object user, UserType type, MultipartFile image) {
        switch (type) {
            case CUSTOMER -> {
                Customer customer = objectMapper.convertValue(user, Customer.class);
                if (customerRepo.findByEmail(customer.getEmail()) != null)
                    return "Email already exists.";
                if (customer.getPassword().length() < 8)
                    return "Password must be at least 8 characters.";
                customer.setPassword(passwordEncoder.encode(customer.getPassword()));
                customer.setProfileImage(fileStorageUtil.storeFile(image));
                customerRepo.save(customer);
                sendWelcomeEmail(customer.getEmail(), customer.getName());
                return "Customer registered successfully.";
            }
            case RESTAURANT -> {
                Restaurant restaurant = objectMapper.convertValue(user, Restaurant.class);
                if (restaurantRepo.findByEmail(restaurant.getEmail()) != null)
                    return "Email already exists.";
                if (restaurant.getPassword().length() < 8)
                    return "Password must be at least 8 characters.";
                restaurant.setPassword(passwordEncoder.encode(restaurant.getPassword()));
                restaurant.setRestaurantLogo(fileStorageUtil.storeFile(image));
                restaurantRepo.save(restaurant);
                sendWelcomeEmail(restaurant.getEmail(), restaurant.getName());
                return "Restaurant registered successfully.";
            }
            case DELIVERY_MAN -> {
                DeliveryMan deliveryMan = objectMapper.convertValue(user, DeliveryMan.class);
                if (deliveryManRepo.findByEmail(deliveryMan.getEmail()) != null)
                    return "Email already exists.";
                if (deliveryMan.getPassword().length() < 8)
                    return "Password must be at least 8 characters.";
                deliveryMan.setPassword(passwordEncoder.encode(deliveryMan.getPassword()));
                deliveryMan.setProfileImage(fileStorageUtil.storeFile(image));
                deliveryManRepo.save(deliveryMan);
                sendWelcomeEmail(deliveryMan.getEmail(), deliveryMan.getName());
                return "DeliveryMan registered successfully.";
            }
            default -> throw new IllegalArgumentException("Unsupported user type.");
        }
    }


    public String forgetPassword(String email, UserType type, int Otp) {
        String newPassword = UUID.randomUUID().toString().substring(0, 8);
        switch (type) {
            case CUSTOMER -> {
                Customer customer = customerRepo.findByEmail(email);
                if (customer == null) return "User not found.";
                if(otpService.verifyOtp(email, UserType.CUSTOMER, Otp)) return "Invalid Otp";
                customer.setPassword(passwordEncoder.encode(newPassword));
                customerRepo.save(customer);
                sendPasswordRecoveryEmail(email, customer.getName(), newPassword);
                return "New password sent to your email.";
            }
            case RESTAURANT -> {
                Restaurant restaurant = restaurantRepo.findByEmail(email);
                if (restaurant == null) return "User not found.";
                if(otpService.verifyOtp(email, UserType.RESTAURANT, Otp)) return "Invalid Otp";
                restaurant.setPassword(passwordEncoder.encode(newPassword));
                restaurantRepo.save(restaurant);
                sendPasswordRecoveryEmail(email, restaurant.getName(), newPassword);
                return "New password sent to your email.";
            }
            case DELIVERY_MAN -> {
                DeliveryMan deliveryMan = deliveryManRepo.findByEmail(email);
                if (deliveryMan == null) return "User not found.";
                if(otpService.verifyOtp(email, UserType.DELIVERY_MAN, Otp)) return "Invalid Otp";
                deliveryMan.setPassword(passwordEncoder.encode(newPassword));
                deliveryManRepo.save(deliveryMan);
                sendPasswordRecoveryEmail(email, deliveryMan.getName(), newPassword);
                return "New password sent to your email.";
            }
            default -> throw new IllegalArgumentException("Unsupported user type.");
        }
    }

    public String changePassword(String token, String oldPassword, String newPassword, UserType type, int Otp) {
        String email = jwtUtil.getEmailFromToken(token.substring(7));
        switch (type) {
            case CUSTOMER -> {
                Customer customer = customerRepo.findByEmail(email);
                if (!passwordEncoder.matches(oldPassword, customer.getPassword()))
                    return "Invalid old password.";
                if(otpService.verifyOtp(email, UserType.CUSTOMER, Otp)) return "Invalid Otp";
                customer.setPassword(passwordEncoder.encode(newPassword));
                customerRepo.save(customer);
                return "Password changed successfully.";
            }
            case RESTAURANT -> {
                Restaurant restaurant = restaurantRepo.findByEmail(email);
                if (!passwordEncoder.matches(oldPassword, restaurant.getPassword()))
                    return "Invalid old password.";
                if(otpService.verifyOtp(email, UserType.RESTAURANT, Otp)) return "Invalid Otp";
                restaurant.setPassword(passwordEncoder.encode(newPassword));
                restaurantRepo.save(restaurant);
                return "Password changed successfully.";
            }
            case DELIVERY_MAN -> {
                DeliveryMan deliveryMan = deliveryManRepo.findByEmail(email);
                if (!passwordEncoder.matches(oldPassword, deliveryMan.getPassword()))
                    return "Invalid old password.";
                if(otpService.verifyOtp(email, UserType.DELIVERY_MAN, Otp)) return "Invalid Otp";
                deliveryMan.setPassword(passwordEncoder.encode(newPassword));
                deliveryManRepo.save(deliveryMan);
                return "Password changed successfully.";
            }
            default -> throw new IllegalArgumentException("Unsupported user type.");
        }
    }

    private void sendWelcomeEmail(String email, String name) {
        String subject = "🎉 Welcome to TastyGo!";
        String body = """
        <html>
            <body style="font-family: Arial, sans-serif; color: #333;">
                <h2>Hi %s,</h2>
                <p>Welcome to <strong>TastyGo</strong>! We're thrilled to have you join our community.</p>
                <p>Start exploring delicious meals and amazing offers tailored just for you.</p>
                <p>🚀 <a href="http://localhost:5173/" style="color: #1e90ff;">Click here to get started</a></p>
                <br/>
                <p>Bon appétit,</p>
                <p><strong>The TastyGo Team</strong></p>
            </body>
        </html>
    """.formatted(name);
        emailUtil.sendHtmlEmail(email, subject, body);
    }


    private void sendPasswordRecoveryEmail(String email, String name, String newPassword) {
        String subject = "🔐 Password Recovery - TastyGo";
        String body = """
        <html>
            <body style="font-family: Arial, sans-serif; color: #333;">
                <h2>Hello %s,</h2>
                <p>We received a request to reset your password. Here is your new temporary password:</p>
                <p style="font-size: 18px; color: #1e90ff;"><strong>%s</strong></p>
                <p>⚠️ Please log in and change your password immediately for better security.</p>
                <p>
                    🔄 <a href="http://localhost:5173/login" style="color: #1e90ff;">Login to TastyGo</a>
                </p>
                <br/>
                <p>Stay safe,</p>
                <p><strong>The TastyGo Security Team</strong></p>
            </body>
        </html>
    """.formatted(name, newPassword);
        emailUtil.sendHtmlEmail(email, subject, body);
    }

}
