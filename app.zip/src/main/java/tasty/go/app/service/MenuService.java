package tasty.go.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import tasty.go.app.model.Menu;
import tasty.go.app.model.Restaurant;
import tasty.go.app.repository.MenuRepository;
import tasty.go.app.repository.OrderRepo;
import tasty.go.app.repository.RestaurantRepo;
import tasty.go.app.util.FileStorageUtil;
import tasty.go.app.util.JwtUtil;

import java.util.List;

@Service
public class MenuService {
    @Autowired private MenuRepository menuRepository;
    @Autowired private RestaurantRepo restaurantRepo;
    @Autowired private OrderRepo orderRepo;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private FileStorageUtil fileStorageUtil;

    public List<Menu> getMenuItemsByRestaurantId(Long restaurantId){
        return menuRepository.findByRestaurantId(restaurantId);
    }

    public Menu addMenuItem(Menu menu, String token, MultipartFile image) throws Exception {
        Restaurant restaurant = getRestaurantFromToken(token);
        menu.setRestaurant_id(restaurant.getId());
        menu.setImage(fileStorageUtil.storeFile(image));
        return menuRepository.save(menu);
    }

    public Menu updateAvailability(Long menuId, String token, String availability) throws Exception {
        Menu menu = getValidatedMenu(menuId, token);
        if (menu == null) return null;
        menu.setAvailable("AVAILABLE".equals(availability));
        return menuRepository.save(menu);
    }

    public Menu deleteMenuItem(Long menuId, String token) throws Exception {
        Menu menu = getValidatedMenu(menuId, token);
        if (menu == null) return null;
        menuRepository.deleteById(menuId);
        return menu;
    }

    public Menu updatePrice(Long menuId, String token, Double price) throws Exception {
        Menu menu = getValidatedMenu(menuId, token);
        if (menu == null) return null;
        menu.setPrice(price);
        return menuRepository.save(menu);
    }

    public Menu updateDiscount(Long menuId, String token, int discount) throws Exception {
        Menu menu = getValidatedMenu(menuId, token);
        if (menu == null) return null;
        menu.setDiscount(discount);
        return menuRepository.save(menu);
    }

    public Menu updateDescription(Long menuId, String token, String description) throws Exception {
        Menu menu = getValidatedMenu(menuId, token);
        if (menu == null) return null;
        menu.setDescription(description);
        return menuRepository.save(menu);
    }

    private Restaurant getRestaurantFromToken(String token) {
        return restaurantRepo.findByEmail(jwtUtil.getEmailFromToken(token.substring(7)));
    }
    private Menu getValidatedMenu(Long menuId, String token) {
        Restaurant restaurant = getRestaurantFromToken(token);
        Menu menu = menuRepository.findById(menuId).orElse(null);
        return (menu != null && menu.getRestaurant_id().equals(restaurant.getId())) ? menu : null;
    }
}

