package tasty.go.app.service;

import com.razorpay.Order;
import com.razorpay.Payment;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import jakarta.annotation.PostConstruct;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import tasty.go.app.model.Cart;
import tasty.go.app.model.Customer;
import tasty.go.app.model.Restaurant;
import tasty.go.app.repository.CartRepo;
import tasty.go.app.repository.CustomerRepo;
import tasty.go.app.repository.RestaurantRepo;
import tasty.go.app.util.DistanceCalculator;
import tasty.go.app.util.EmailUtil;

import java.util.List;
import java.util.UUID;

@Service
public class PaymentService {
    @Value("${razorpay.api.key}")
    private String apiKey;
    @Value("${razorpay.api.secret}")
    private String apiSecret;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private EmailUtil emailUtility;
    @Autowired
    private CartRepo cartRepo;
    @Autowired
    private RestaurantRepo restaurantRepo;
    private RazorpayClient client;
    @PostConstruct
    public void init() throws RazorpayException {
        client = new RazorpayClient(apiKey,apiSecret);
    }

    public String createOrder(String token) throws RazorpayException {
        Customer customer = customerService.getLoggedInUser(token);
        List<Cart> cartItems = cartRepo.findByUserId(customer.getId());

        if (cartItems.isEmpty()) {
            throw new IllegalStateException("Cart is empty. Cannot create order.");
        }

        double totalAmount = cartRepo.getTotalCartPriceByUserId(customer.getId());
        Long restaurantId = cartItems.getFirst().getRestaurantId();
        Restaurant restaurant = restaurantRepo.findById(restaurantId).orElseThrow();

        double distance = DistanceCalculator.calculateDistance(
                customer.getLatitude(), customer.getLongitude(),
                restaurant.getLatitude(), restaurant.getLongitude()
        );
        double deliveryCharge = distance * 25.0;
        double grandTotal = totalAmount + deliveryCharge;

        RazorpayClient razorpayClient = new RazorpayClient(apiKey, apiSecret);
        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", (int)(grandTotal * 100)); // in paise
        orderRequest.put("currency", "INR");
        orderRequest.put("receipt", "tastygo_rcpt_" + UUID.randomUUID().toString().replace("-", "").substring(12));

        Order order = razorpayClient.orders.create(orderRequest);
        return order.toString();
    }

    public boolean verifyPayment(String paymentId) {
        try {
            Payment payment = client.payments.fetch(paymentId);
            String status = payment.get("status");
            return status.equals("captured"); // or "authorized" based on your flow
        } catch (RazorpayException e) {
            System.out.println("Payment verification failed: " + e.getMessage());
            return false;
        }
    }
}