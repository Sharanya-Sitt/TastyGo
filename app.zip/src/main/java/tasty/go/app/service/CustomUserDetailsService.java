package tasty.go.app.service;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import tasty.go.app.model.Customer;
import tasty.go.app.model.DeliveryMan;
import tasty.go.app.model.Restaurant;
import tasty.go.app.repository.CustomerRepo;
import tasty.go.app.repository.DeliveryManRepo;
import tasty.go.app.repository.RestaurantRepo;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomUserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private CustomerRepo customerRepo;
    @Autowired
    private DeliveryManRepo deliveryManRepo;
    @Autowired
    private RestaurantRepo restaurantRepo;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Customer customer = customerRepo.findByEmail(email);
        if (customer != null) {
            List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_CUSTOMER"));
            return new org.springframework.security.core.userdetails.User(customer.getEmail(), customer.getPassword(), authorities);
        }

        Restaurant restaurant = restaurantRepo.findByEmail(email);
        if (restaurant != null) {
            List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_RECRUITER"));
            return new org.springframework.security.core.userdetails.User(restaurant.getEmail(), restaurant.getPassword(), authorities);
        }
        DeliveryMan deliveryMan = deliveryManRepo.findByEmail(email);
        if (deliveryMan != null) {
            List<SimpleGrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_DELIVERYMAN"));
            return new org.springframework.security.core.userdetails.User(deliveryMan.getEmail(), deliveryMan.getPassword(), authorities);
        }

        throw new UsernameNotFoundException("User not found with email: " + email);
    }
}

