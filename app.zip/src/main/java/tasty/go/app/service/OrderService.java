package tasty.go.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tasty.go.app.model.*;
import tasty.go.app.repository.CartRepo;
import tasty.go.app.repository.MenuRepository;
import tasty.go.app.repository.OrderRepo;
import tasty.go.app.repository.RestaurantRepo;
import tasty.go.app.util.DistanceCalculator;
import tasty.go.app.util.EmailUtil;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {
    @Autowired
    private CartRepo cartRepo;
    @Autowired
    private CustomerService customerService;
    @Autowired
    private OrderRepo orderRepo;
    @Autowired
    private PaymentService paymentService;
    @Autowired
    private EmailUtil emailUtil;
    @Autowired
    private RestaurantService restaurantService;
    @Autowired
    private RestaurantRepo restaurantRepo;
    @Autowired private MenuRepository menuRepo;

    public String checkout(String token, String paymentMode, String razorpayPaymentId) {
        Customer customer = customerService.getLoggedInUser(token);
        List<Cart> cartItems = cartRepo.findByUserId(customer.getId());
        Double total = cartRepo.getTotalCartPriceByUserId(customer.getId());

        if (cartItems.isEmpty()) return "Cart is empty";

        String paymentDetails;
        if (paymentMode.equals("ONLINE")) {
            if (razorpayPaymentId == null || razorpayPaymentId.isEmpty()) {
                return "Payment failed or not provided";
            }
            boolean isPaid = paymentService.verifyPayment(razorpayPaymentId);
            paymentDetails = isPaid ? "Payment successful with id: " + razorpayPaymentId : "Payment failed, pay on delivery enabled.";
        } else {
            paymentDetails = "Cash on Delivery";
        }
        Long restaurantId = cartItems.getFirst().getRestaurantId();
        Restaurant restaurant = restaurantRepo.findById(restaurantId).orElse(null);
        assert restaurant != null;
        double distance = DistanceCalculator.calculateDistance(
                customer.getLatitude(), customer.getLongitude(), restaurant.getLatitude(), restaurant.getLongitude());
        Double deliveryCharge = distance * 25.0;
        Order order = new Order();
        order.setCustomerId(customer.getId());
        order.setRestaurantId(restaurantId);
        order.setOrderTime(LocalDateTime.now());
        order.setStatus("PLACED");
        order.setDeliveryAddress(customer.getAddress());
        order.setPaymentMode(paymentMode);
        order.setTotalAmount(total);
        order.setDeliveryCharge(deliveryCharge);
        order.setPaymentDetails(paymentDetails);
        order.setDeliveryAddress(customer.getAddress());
        order.setCustomerEmail(customer.getEmail());
        order.setCustomerPhone(customer.getPhone());
        order.setCustomerDistanceFromRestaurant(distance);

        orderRepo.save(order);
        String title = "Your TastyGo Order Has Been Placed Successfully!";
        StringBuilder itemRows = new StringBuilder();
        for (Cart cart : cartItems) {
            Menu menu = menuRepo.findById(cart.getMenuId()).orElse(null);
            if (menu != null) {
                itemRows.append(String.format("""
                            <tr>
                                <td>%s</td>
                                <td>%d</td>
                                <td>₹%.2f</td>
                                <td>₹%.2f</td>
                            </tr>
                        """, menu.getFood_name(), cart.getQuantity(), menu.getPrice(), cart.getQuantity() * menu.getPrice()));
            }
        }

        String emailBody = """
                <html>
                <body style='font-family: Arial, sans-serif; color: #333;'>
                    <h2 style='color: #4CAF50;'>🧾 TastyGo Order Invoice</h2>
                    <p>Hi %s,</p>
                    <p>Thank you for ordering with <strong>TastyGo</strong>! Here's your order summary:</p>
                
                    <h3>📌 Customer Details</h3>
                    <table>
                        <tr><td><strong>Name:</strong></td><td>%s</td></tr>
                        <tr><td><strong>Phone:</strong></td><td>%s</td></tr>
                        <tr><td><strong>Email:</strong></td><td>%s</td></tr>
                        <tr><td><strong>Delivery Address:</strong></td><td>%s</td></tr>
                    </table>
                
                    <h3>🏠 Restaurant Info</h3>
                    <table>
                        <tr><td><strong>Restaurant:</strong></td><td>%s</td></tr>
                        <tr><td><strong>Distance:</strong></td><td>%.2f km</td></tr>
                    </table>
                
                    <h3>🍽️ Order Summary</h3>
                    <table cellpadding='8' cellspacing='0' border='1' style='border-collapse: collapse; width: 100%%;'>
                        <tr style='background-color: #f2f2f2;'>
                            <th>Item</th><th>Qty</th><th>Unit Price</th><th>Total</th>
                        </tr>
                        %s
                        <tr><td colspan='3'><strong>Subtotal</strong></td><td><strong>₹%.2f</strong></td></tr>
                        <tr><td colspan='3'>Delivery Charge</td><td>₹%.2f</td></tr>
                        <tr style='background-color: #f9f9f9; font-weight: bold;'>
                            <td colspan='3'>Total Amount</td><td>₹%.2f</td>
                        </tr>
                        <tr><td colspan='3'>Payment Mode</td><td>%s</td></tr>
                        %s
                    </table>
                
                    <p>You can track your order status from your account dashboard.</p>
                    <p>We hope you enjoy your meal! 🍴</p>
                    <br>
                    <p style='font-size: 0.9em; color: #888;'>This is an automated email. Please do not reply.</p>
                    <p>– Team TastyGo</p>
                </body>
                </html>
                """.formatted(
                customer.getName(),
                customer.getName(),
                customer.getPhone(),
                customer.getEmail(),
                customer.getAddress(),
                restaurant.getName(),
                distance,
                itemRows,
                total,
                deliveryCharge,
                total + deliveryCharge,
                paymentMode,
                paymentMode.equals("ONLINE") ? "<tr><td colspan='3'>Razorpay Payment ID</td><td>" + razorpayPaymentId + "</td></tr>" : ""
        );

        emailUtil.sendHtmlEmail(customer.getEmail(), title, emailBody);

        cartRepo.deleteByUserId(customer.getId());
        return "Order placed successfully";
    }


    public String cancelOrder(String token, Long orderId) {
        Customer customer = customerService.getLoggedInUser(token);
        Order order = orderRepo.findById(orderId).orElse(null);
        if (order == null || !order.getCustomerId().equals(customer.getId())) {
            return "Order not found or failed to cancel order";
        }
        if (order.getStatus().equals("PLACED")) {
            order.setStatus("CANCELLED");
            return "Order cancelled successfully";
        }
        orderRepo.save(order);
        return "Order cannot be cancelled";
    }


}
