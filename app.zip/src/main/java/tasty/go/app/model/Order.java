package tasty.go.app.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity @Data @Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private Long restaurantId;
    private LocalDateTime orderTime;
    private String status;
    private Double totalAmount;
    private Double deliveryCharge;
    private String deliveryAddress;
    private String customerPhone;
    private String customerEmail;
    private Double customerDistanceFromRestaurant;
    private String paymentMode;
    private String paymentStatus;
    private String paymentDetails;
    private Long deliveryManId;
}
