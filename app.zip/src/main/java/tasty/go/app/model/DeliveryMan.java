package tasty.go.app.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@Table (name = "delivery_man")
@Entity @AllArgsConstructor @NoArgsConstructor @Getter @Setter
public class DeliveryMan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String password;
    private String profileImage;
    private String phone;
    private String city;
    private String state;
    private int pin_code;
    private Double latitude;
    private Double longitude;
    private Double rating;
    private int ratingCount;
    private boolean isAvailable;
    private int otp;
    private LocalDateTime otp_expiry;
}
