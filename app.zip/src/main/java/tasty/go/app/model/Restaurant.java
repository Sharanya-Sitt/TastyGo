package tasty.go.app.model;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@Entity @Table(name = "restaurant")
@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class Restaurant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String password;
    private String email;
    private String restaurantLogo;
    private String description;
    private String address;
    private String city;
    private String state;
    private int pin_code;
    private Double latitude;
    private Double longitude;
    private boolean isOpen;
    private double rating;
    private int numberOfRatings;
    private int otp;
    private LocalDateTime otp_expiry;
}
