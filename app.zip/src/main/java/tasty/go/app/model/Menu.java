package tasty.go.app.model;
import jakarta.persistence.*;
import lombok.*;

@Data
@Entity @Table(name = "menu")
@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class Menu {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long restaurant_id;
    private String food_name;
    private String description;
    private Double price;
    private int discount;
    private String image;
    private String type; //veg, non-veg
    private String category; //Indian, Chinese, Italian, Continental
    private boolean isAvailable;
}
