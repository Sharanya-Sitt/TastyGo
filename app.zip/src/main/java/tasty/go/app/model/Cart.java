package tasty.go.app.model;

import jakarta.persistence.*;
import lombok.*;

@Data
@Entity @Table(name="cart")
@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private Long restaurantId;
    private Long menuId;
    private int quantity;
    private double price;
}
