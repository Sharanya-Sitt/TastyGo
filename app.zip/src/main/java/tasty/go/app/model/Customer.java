package tasty.go.app.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

@Data
@Entity @Table(name = "customer")
@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(unique = true)
    private String password;
    private String profileImage;
    private String email;
    private String phone;
    private String address;
    private String city;
    private String state;
    private int pin_code;
    private Double latitude;
    private Double longitude;
    private int otp;
    private LocalDateTime otp_expiry;
}
