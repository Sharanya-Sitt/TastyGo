package tasty.go.app.dto;

public enum UserType {
    CUSTOMER,RESTAURANT,DELIVERY_MAN
}
