package tasty.go.app.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RestaurantsDTO {
    private Long id;
    private String name;
    private String logo;
    private double rating;
    private int numberOfRatings;
    private double averageDiscount;
    private double distanceInKm;
}
