package tasty.go.app.dto;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AiReqDTO {
    private List<Content> contents;

    @Getter
    @Setter
    public static class Content {
        private String role;
        private List<Part> parts;
    }

    @Getter
    @Setter
    public static class Part {
        private String text;

        public Part() {}

        public Part(String text) {
            this.text = text;
        }
    }
}